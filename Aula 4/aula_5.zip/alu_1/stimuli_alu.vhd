library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity stimuli_module is
	generic
	(
	WIDTH	: natural := 8
	);
	
	port
	(
	one_op		     : out STD_LOGIC_VECTOR(WIDTH-1 downto 0); 
	rb_op	: 	out STD_LOGIC_VECTOR(WIDTH-1 downto 0);
	alu_ctrl         : out STD_LOGIC      
	);
	
end stimuli_module ;

architecture test of stimuli_module  is
-- "Time" that will elapse between test vectors we submit to the component.
constant TIME_DELTA : time := 100 ns;      -- choose any value

 
begin

simulation : process

-- procedure for vector generation (as input, one_op ,  rb_op and alu_ctrl)



begin

-- test vectors application
-- you may use the following syntax

--		for i in decimal_1 to decimal_2 loop
--          any command
--		end loop;




wait;
end process simulation;
end architecture test;